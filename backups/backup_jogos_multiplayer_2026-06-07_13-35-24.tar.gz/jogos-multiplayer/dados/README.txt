Arquivos persistentes do servidor
